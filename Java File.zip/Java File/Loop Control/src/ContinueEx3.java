
public class ContinueEx3 {

	public static void main(String[] args) {
		int x=1;
		do{ 
			System.out.println("Hello");
			x++;
			if(x==3) {
				continue;
			}
			System.out.println("Anmol Dev..");
		}while(x<=5);

	}

}
