
public class LoopEx2 {

	public static void main(String[] args) {
		int x=1;
		for(;x<=5;) {  // for(;;) { //infinite loop 
			System.out.println("Anmol dev");
			x++;
		}
	}

}
