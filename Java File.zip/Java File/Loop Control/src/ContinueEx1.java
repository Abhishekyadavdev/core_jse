
public class ContinueEx1 {

	public static void main(String[] args) {
		for(int x=1;x<=5;x++) { 
			System.out.println("Hello");
//			if(x==3) { 
			if(x>=3) { 
				continue;
			}
			System.out.println("Anmol Dev");
		}
	}

}
