
public class BreakEx1 {

	public static void main(String[] args) {
		for(int x=1;x<=8;x++) { 
			System.out.println("Hello");
			//if(x==3) {
//			if(x>=3) {
			if(x++>=3) {
				break;
			}
			System.out.println("Anmol Dev");
			
//			if(x==3) {
//				break;
//			}else {
//				break;
//			}
//			System.out.println("Anmol Dev");//error
		}
	}

}
