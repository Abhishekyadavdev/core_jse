
public class LoopEx3 {

	public static void main(String[] args) {
		for(int x=1;x<=5;x++,System.out.println("Hi")) { 
			System.out.println("Anmol Dev");
		}
//		System.out.println("-------");
//		for(int x=1;x<=5;x++,System.out.println("Hi"),System.out.println("Ok")) { 
//			System.out.println("Anmol dev");
//		}
//		System.out.println("-------");
//		for(int x=1;x<=5;x++,System.out.println("Hi"),System.out.println("Ok")) { 
//			System.out.println("Anmol Dev");
//			System.out.println("Hello");
//		}
//		System.out.println("-------");
//		
//		//for(int x=1,System.out.println("Hello");x<=5;x++) { //error
//		
//		int x=1;
//		for(System.out.println("Hello");x<=5;x++,System.out.println("Hi")) { 
//			System.out.println("Anmol Dev");
//		}
//		System.out.println("-------");
//		
//		int y=1;
//		for(y++,System.out.println("Hello");y<=5;y++,System.out.println("Hi")) { 
//			System.out.println("Anmol Dev");
//		}

	}

}
