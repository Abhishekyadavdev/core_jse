
public class FibonacciSeries {

	public static void main(String[] args) {
java.util.Scanner sc=new java.util.Scanner(System.in);
		
		System.out.println("Enter End no for Fabonacii series:");
		int n=sc.nextInt();
		int a=0,b=1,c=a+b;
		System.out.print(a+" "+b+" ");
		while(c<=n) {
			System.out.print(c+" ");
			a=b;
			b=c;
			c=a+b;
		}
	}

}
