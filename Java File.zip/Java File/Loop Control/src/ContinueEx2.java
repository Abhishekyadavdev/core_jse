
public class ContinueEx2 {

	public static void main(String[] args) {
		int x=1;
		while(x<=5){ 
			System.out.println("Hello");
//			x++;
			if(x==3) {
				continue;
			}
			x++;
			System.out.println("Anmol Dev..");
			
		}

	}

}
