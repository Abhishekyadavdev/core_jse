
public class LoopEx5 {

	public static void main(String[] args) {
		java.util.Scanner sc=new java.util. Scanner( System.in );
		
		System.out.println("Enter a number");
		int a=sc.nextInt();
		for(int x=1;x<=a;x++) { 
			System.out.println(x);
		}
		
//		for(int x=1;x++<=5;x++) { 
//			System.out.println(x);
//		}

	}

}
