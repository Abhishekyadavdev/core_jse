
public class FibonacciSeriesEx {

	public static void main(String[] args) {
java.util.Scanner sc=new java.util.Scanner(System.in);
		
		System.out.println("Enter no for Fabonacii series:");
		int n=sc.nextInt();
		int a=0,b=1,c=a+b;
		System.out.print(a+" "+b+" ");
		n-=2;
		while(n>0)
		{
			a=b;
			b=c;
			c=a+b;
			System.out.print(c+" ");
			n--;
		}
	}

}
