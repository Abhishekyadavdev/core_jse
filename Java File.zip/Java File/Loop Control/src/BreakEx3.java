
public class BreakEx3 {

	public static void main(String[] args) {
		int x=1;
		do{ 
			System.out.println("Hello");
			if(x==3) {
				break;
			}
			System.out.println("Anmol Dev..");
			x++;
		}while(x<=5);

	}

}
