public class VarArgsEx3 {
	public static void main(String[] args) {
		show(6);
		//priority: Same-type->TypeCasting->Boxing->Var-Args
	}
	static void show(int a) {
		System.out.println("int");
	}
	static void show(double a) {
		System.out.println("double");
	}
	static void show(Integer a) {
		System.out.println("Integer");
	}
	static void show(int...a) {
		System.out.println("int var-args");
	}
}