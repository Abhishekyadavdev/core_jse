
public class pattern_8 {

	public static void main(String[] args) {
//		int a=5;
//		int b=1;
//		int c=7;
//		for(int x=1;x<=a;x++) {
//			for(int y=1;y<=b;y++) {
//				System.out.print("*");
//			}
//			for(int y=1;y<=c;y++) {
//				System.out.print(" ");
//			}
//			if(x==a) {
//				b--;
//			}
//			for(int y=1;y<=b;y++) {
//				System.out.print("*");
//			}
//			System.out.println();
//			b++;
//			c-=2;
//		}
		
		
		int x=5;
		for(int i=1; i<=x; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			for(int j=1; j<2*(x-i); j++)
			{
				System.out.print(" ");
			}
			for(int j=1; j<=i; j++)
			{
				if(j!=5)
					System.out.print("*");
				
			}
			
			System.out.println();
		}

	}

}
