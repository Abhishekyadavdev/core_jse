
public class pattern_5 {

	public static void main(String[] args) {
//		int a=4;
//		int b=3;
//		int c=1;
//		for(int x=1;x<=a;x++) {
//			for(int y=1;y<=b;y++) {
//				System.out.print(" ");
//			}
//			for(int y=1;y<=c;y++) {
//				System.out.print("*");
//			}
//			System.out.println();
//			b--;
//			c+=2;
//		}
		
		
		//Second Soution
		
		int x=4;
		for(int i=1; i<=x; i++)
		{
			for(int j=1; j<=x-i; j++)
			{
				System.out.print(" ");
			}
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
				
			}
			for(int j=2; j<=i; j++)
			{
				System.out.print("*");
				
			}
			System.out.println();
			
		}
		

	}

}
