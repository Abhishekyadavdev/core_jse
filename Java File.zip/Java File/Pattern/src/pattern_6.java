
public class pattern_6 {

	public static void main(String[] args) {
//		int a=9;
//		int b=1;
//		for(int x=1;x<=a;x++) {
//			for(int y=1;y<=b;y++) {
//				System.out.print("*");
//			}
//			System.out.println();
//			if(x<=a/2) {
//				b++;
//			}else {
//				b--;
//			}
//		}
		
		
		int x=5;
		for (int i=1; i<=x; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			
			System.out.println();
		}
		for (int i=x; i>=1; i--)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			
			System.out.println();
		}

	}

}
