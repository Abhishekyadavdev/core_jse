
public class pattern_3 {

	public static void main(String[] args) {
//		int a=4;
//		int b=4;
//		for(int x=1;x<=a;x++) {
//			for(int y=1;y<=b;y++) {
//				System.out.print("*");
//			}
//			System.out.println();
//			b--;
//		}
		
		// Second Method
		
		int x=10;
		for(int i=x; i>=1;i--)
		{
			for(int j=1; j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
			
		}
	}

}
