
public class pattern_1 {

	public static void main(String[] args) {
		java.util.Scanner in=new java.util.Scanner(System.in);
		int x=4;
		int y=4;
		for(int i=1; i<=x; i++)
		{
			for (int j=1; j<=y; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
