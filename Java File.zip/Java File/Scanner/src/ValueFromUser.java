import java.io.IOException;
import java.util.*;
public class ValueFromUser {

	public static void main(String[] args) throws IOException {
		Scanner in=new Scanner(System.in);
		
		// Integer
		int a=in.nextInt();
		System.out.println("INT : "+a);
		
		//float & double
		float b=in.nextFloat();
		double c=in.nextDouble();
		System.out.println("Float : "+b+"\nDouble : "+c);
		
		//String & Boolean
		String d=in.next();
		boolean e=in.nextBoolean();
		System.out.println("String : "+d+"\nBoolean : "+e);
		
		//char
		char f=(char)System.in.read();
		System.out.println("Char : "+f);
	}

}
