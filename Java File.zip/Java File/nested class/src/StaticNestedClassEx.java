class OO{ //outer or upper class
	int x=10;
	private int y=20;
	static int z=30;
	void m1() {
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
		//System.out.println(h);//error
		System.out.println(B.g);
		B b=new B();
		System.out.println(b.h);
		b.m();
	}
	static class B{ //static nested class 
		int h=45;
		static int g=55;
		void m() {
//			System.out.println(x);//error
//			System.out.println(y);//error
			System.out.println(z);
			System.out.println(h);
		}
	}
}
public class StaticNestedClassEx {
	public static void main(String[] args) {
		System.out.println(OO.z);
		System.out.println(OO.B.g);
		//B b=new B();//error
		OO.B b=new OO.B();
		System.out.println(b.h);
		b.m();
		//System.out.println(b.x);//error
		OO a=new OO();
		System.out.println(a.x);
		//System.out.println(a.h);//error
		a.m1();
	}
}