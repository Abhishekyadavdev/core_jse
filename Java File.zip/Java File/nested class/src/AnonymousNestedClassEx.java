class Xyz{
	void m1() {
		System.out.println("Hello XYZ");
	}
	void m2() {
		System.out.println("Hi XYZ");
	}
}
interface Abc{
	void m1();
	void m2();
}
public class AnonymousNestedClassEx {
	public static void main(String[] args) {
		
		Xyz x=new Xyz(){
			void m1() {
				System.out.println("rthurthjrt");
			}
			void m2() {
				System.out.println("retyryrtyrt");
			}
		};
		x.m1();
		x.m2();
		
		Abc a=new Abc() {
			@Override
			public void m1() {
				System.out.println("jhdrsgfef");
			}
			@Override
			public void m2() {
				System.out.println("yrtyrtyrty");
			}
		};
		a.m1();
		a.m2();
		
		Abc aa=new Abc() {
			@Override
			public void m1() {
				System.out.println("dtgfhrtfhrthrt");
			}
			@Override
			public void m2() {
				System.out.println("tyrtyutu56u56tyu");
			}
		};
		aa.m1();
		aa.m2();
		
	}
}