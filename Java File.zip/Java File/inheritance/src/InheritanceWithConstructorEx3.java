class AAAAA{
	int x=10;
	AAAAA(int a) {
		x=a;
		System.out.println("Hi A");
	}
}
class BBBBB extends AAAAA {
	int y=20;
	
	BBBBB() { 
		super(7);
		System.out.println("Hi B");
	}
}
public class InheritanceWithConstructorEx3 {
	public static void main(String[] args) {
		BBBBB b1=new BBBBB();
		AAAAA a1=new AAAAA(5);
		System.out.println(b1.x+" "+b1.y);
		System.out.println(a1.x);
	}
}