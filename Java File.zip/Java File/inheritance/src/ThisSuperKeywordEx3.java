class PP{
	int x=10;
	void print(int x) {
		System.out.println(this.x);
		x=this.x;
		x++;
		System.out.println("Hello" +x);
	}
}
public class ThisSuperKeywordEx3 {
	public static void main(String[] args) {
		PP p=new PP();
		p.print(40);
		System.out.println(p.x);
	}
}