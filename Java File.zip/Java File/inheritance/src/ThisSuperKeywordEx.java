class C{
	int x=10;
	int pp=70;
	void print() {
		System.out.println("Hello C");
	}
}
class D extends C {
	int y=20;
	int x=50;
	void m() {
		int z=40;
		int x=80;
		System.out.println(x);//80
		System.out.println(this.x);//50
		System.out.println(super.x);//10
		System.out.println(this.y);
		System.out.println(z);
		print();//Hello D
		this.print();//Hello D
		super.print();//Hello C
	}
	void print() {
		System.out.println("Hello D");
		//System.out.println(z);//error
	}
}
public class ThisSuperKeywordEx {
	public static void main(String[] args) {
		D d=new D();
		d.m();
		System.out.println(d.x);//50
		//System.out.println(d.super.x);//error
		d.print();//Hello D
		//d.super.print();//error
		System.out.println(d.y);
		//System.out.println(d.z);//error
//		System.out.println(d.pp);
		C c=new C();
		System.out.println(c.x);
	}
}