public class ClassObjectEx3 {
	int x;
	String y;
	void show() {
		System.out.println(x+y);
	}
	public static void main(String[] args) {
		ClassObjectEx3 a=new ClassObjectEx3();
		a.x=10;
		ClassObjectEx3 b=new ClassObjectEx3();
		b.y="Ram";
		a.show();
		b.show();
	}
}