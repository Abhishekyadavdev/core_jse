class Emp{
	//System.out.println("Hello Emp");//error
	void m() {
		System.out.println("Hello Emp");
	}
	String name;		//Data Member
	int salary;			//Data Member
	//salary=9000;//error	
	String cname;		//Data Member
	void show() {		//Method/Member Function
		System.out.println(name+" "+salary+" "+cname);
	}
	void input(String n,int s, String c) {	//Method/Member Function
		name=n;
		salary=s;
		cname=c;
	}
}
public class ClassObjectEx2 {
	public static void main(String[] args) {
		Emp a=new Emp();
		Emp b=new Emp();
		Emp c=new Emp();
		Emp d=new Emp();
		
		a.show();
		b.show();
		c.show();
		d.show();
		
		a.input("Yoyo Gupta",98000, "ABC");
		b.input("Gogo Singh",75000, "XYZ");
		c.input("Teja Khan",120000, "PQR");
		d.input("Cheetah Sharma",1500000, "MNO");
		
		a.show();
		b.show();
		c.show();
		d.show();
		
		int total=a.salary+b.salary+c.salary+d.salary;
		System.out.println("Total salary: "+total);
	}
}