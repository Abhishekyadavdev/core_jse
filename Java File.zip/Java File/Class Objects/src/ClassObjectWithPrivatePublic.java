class Empp{
	//System.out.println("Hello Emp");//error
	void m() {
		System.out.println("Hello Emp");
	}
	private String name;		//Data Member
	private int salary;			//Data Member
	//salary=9000;//error	
	private String cname;		//Data Member
	public void show() {		//Method/Member Function
		System.out.println(name+" "+salary+" "+cname);
	}
	public void input(String n,int s, String c) {	//Method/Member Function
		name=n;
		salary=s;
		cname=c;
	}
}
public class ClassObjectWithPrivatePublic {
	public static void main(String[] args) {
		Empp a=new Empp();
		Empp b=new Empp();
		Empp c=new Empp();
		Empp d=new Empp();
		
		a.show();
		b.show();
		c.show();
		d.show();
		
		a.input("Yoyo Gupta",98000, "ABC");
		b.input("Gogo Singh",75000, "XYZ");
		c.input("Teja Khan",120000, "PQR");
		d.input("Cheetah Sharma",1500000, "MNO");
		
		a.show();
		b.show();
		c.show();
		d.show();
		
		
		//int total=a.salary+b.salary+c.salary+d.salary;//error
	}
}