class AAA{
	int x;
	String y;
	//y=23; //error
	void m() {
		x=23;	// initialize allowed to method or function block
	}
	void show() {
		System.out.println(x+y);
	}
}
public class ClassObjectQue3 {
	public static void main(String[] args) {
		AAA a=new AAA();
		a.x=10;
		a.m();
		AAA b=new AAA();
		b.y="Ram";
		b.m();
		b.x=90;
		a.show();
		b.show();
	}
}