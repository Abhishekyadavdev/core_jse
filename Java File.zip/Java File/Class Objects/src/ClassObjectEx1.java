class Employee{
	String name;
	int salary;
	String cname;
}
public class ClassObjectEx1 {
	public static void main(String[] args) {
		Employee a=new Employee();
		Employee b=new Employee();
		Employee c=new Employee();
		Employee d=new Employee();
		
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
		
//		System.out.println(name);//error
		System.out.println(a.name+" "+a.salary+" "+a.cname);
		System.out.println(b.name+" "+b.salary+" "+b.cname);
		System.out.println(c.name+" "+c.salary+" "+c.cname);
		System.out.println(d.name+" "+d.salary+" "+d.cname);
		
		a.name="Yoyo Gupta";
		a.salary=98000;
		a.cname="ABC";
		
		b.name="Gogo Singh";
		b.salary=75000;
		b.cname="ABC";
		
		c.name="Teja Khan";
		c.salary=120000;
		c.cname="PQR";
		
		d.name="Cheetah Sharma";
		d.salary=1500000;
		d.cname="MNO";
		

		System.out.println(a.name+" "+a.salary+" "+a.cname);
		System.out.println(b.name+" "+b.salary+" "+b.cname);
		System.out.println(c.name+" "+c.salary+" "+c.cname);
		System.out.println(d.name+" "+d.salary+" "+d.cname);
		
		int total=a.salary+b.salary+c.salary+d.salary;
		System.out.println("Total salary: "+total);
	}
}