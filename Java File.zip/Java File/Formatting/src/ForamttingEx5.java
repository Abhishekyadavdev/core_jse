
public class ForamttingEx5 {

	public static void main(String[] args) {
		
		System.out.println();//allowed
		//System.out.print();//error
		//System.out.printf();//error
		//System.out.format();//error
		
	}

}
