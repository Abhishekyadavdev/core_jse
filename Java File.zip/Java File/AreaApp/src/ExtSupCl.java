
public class ExtSupCl {
	float pi=3.14159f;
	void process() {
		
	}
	void result() {
		
	}
}
