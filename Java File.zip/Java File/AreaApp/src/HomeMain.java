import java.util.*;
public class HomeMain {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		
	}

}
