
public class AreaofCube extends ExtSupCl implements DataBase{

}
