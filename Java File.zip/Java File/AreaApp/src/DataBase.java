
public interface DataBase {
	void process();
	void result();
	
}
