
public class functionEx1 {

	public static void main(String[] args) {
		add();
		//add(4,8);//error
		add();
	}
	static void add() {// No arguments and No Return Type
		int a=10, b=20;
		int r=a+b;
		System.out.println("Sum: "+r);
	}
}
