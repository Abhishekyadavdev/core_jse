
public class functionEx {
	static void show() { //Function Declaration
		System.out.println("Software Dev..");
		System.out.println("Web Dev..");
	}
	public static void main(String[] args) {
		System.out.println("Hello Main");
		display(); //Function Calling/Invocation
		System.out.println("OK1");
		System.out.println("OK2");
		show(); //Function Calling/Invocation 
		display(); //Function Calling/Invocation 

	}
	static void display() { //Function Declaration
		System.out.println("Hello Anmol");
		System.out.println("Hi INDIA");
		System.out.println("Anmol Dev..");
	}
}
