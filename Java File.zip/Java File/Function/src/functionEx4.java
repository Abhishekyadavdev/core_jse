
public class functionEx4 {
	static int add(int a,int b) {
		int r=a+b;
		return r;
	}
	public static void main(String[] args) {
		int r=add(15,15);
		System.out.println("Sum: "+r);
	}
}
