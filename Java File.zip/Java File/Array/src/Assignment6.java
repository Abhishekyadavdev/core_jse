import java.util.*;
public class Assignment6 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int a[][];
		System.out.println("Enter the no of lines row you input : ");
		int m=in.nextInt();
		System.out.println("Enter the no of each row values : ");
		int n=in.nextInt();
	a=new int[m][n];
		
		
		for(int i=0; i<m; i++)
		{
			for(int j=0; j<n; j++)
			{
				System.out.print("Enter the value of a["+i+"] ["+j+"]  : ");
				a[i][j]=in.nextInt();
			}
		}
		
		int max=a[0][0];
		
		for(int i=0; i<m; i++)
		{
			for(int j=1; j<n; j++)
			{
				if (a[i][j]>max)
					max=a[i][j];
			}
			
		}
		
			System.out.println(" Max value is : "+max);
		
	}

}
