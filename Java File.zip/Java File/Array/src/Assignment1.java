// Write a program to find max element in a 1D array.

	public class Assignment1 {
		public static void main(String[] args) {
			
			int a[]= {3,0,8,5,7,6};
			int max=a[0],
				term=0;
			
				for(int i=1; i<a.length; i++) {
					if (a[i]>max)
					{
						max=a[i];
						term=i;
					}
				}
			
			System.out.print("Elements are : ");
				for (int x:a)
				{
					System.out.print(x+" ");
				}
			System.out.println("\nMaximum Element are : "+max+
								"\nElementh term is : "+term);
		}
}
