import java.util.Scanner;

public class Assignment8 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int a[][];
		System.out.println("Enter the no of lines row you input : ");
		int m=in.nextInt();
		System.out.println("Enter the no of each row values : ");
		int n=in.nextInt();
	a=new int[m][n];
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			System.out.print("Enter the value of a["+i+"] ["+j+"]  : ");
			a[i][j]=in.nextInt();
		}
	}
	
	int sum=0;
	
	for(int i=0; i<m; i++)
	{
		int lsum=0;
		
		for(int j=0; j<n; j++)
		{
			lsum+=a[i][j];
			sum+=a[i][j];
			
		}
		System.out.println(" Sum of Row "+(i+1)+" is : "+lsum);
	}
	
		System.out.println("Sum of multiarray values : "+sum);
	
	}
}
