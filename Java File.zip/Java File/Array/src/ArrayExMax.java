import java.util.Scanner;

public class ArrayExMax {
	public static void main(String[] args) {
		int a[]=new int[]{5,7,2,7,3,9,1,7,8};
		
		int max=a[0];
		for(int x:a) {
			if(x>max) {
				max=x;
			}
		}
		System.out.println("Maximum: "+max);
	}
}