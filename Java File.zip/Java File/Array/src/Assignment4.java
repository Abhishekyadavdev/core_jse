
public class Assignment4 {
	public static void main(String[] args) {
		
		int a[]= {1,2,3,4,5};
		int sum=0;
		
		System.out.print("Elements are : ");
		for(int x:a)
		{
			System.out.print(x+" ");
			sum+=x;
		}
		
		System.out.println("\nTotal Elements values sum is : "+sum);
	
	}
}
