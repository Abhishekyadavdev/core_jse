import java.util.Scanner;

public class ArrayExMin {
	public static void main(String[] args) {
		int a[]=new int[]{5,7,2,7,3,9,1,7,8};
		
		int min=a[0];
		for(int x:a) {
			if(x<min) {
				min=x;
			}
		}
		System.out.println("Minimum: "+min);
	}
}