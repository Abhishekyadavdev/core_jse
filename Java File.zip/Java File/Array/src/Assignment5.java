
public class Assignment5 {
	public static void main(String[] args) {
	
		int a[]= {1,2,3,4,5};
		int multi=1;
		
		System.out.print("Elements are : ");
		for(int i:a)
		{
			System.out.print(i+" ");
			multi*=i;
		}
		
		System.out.println("\nTotal Emements value multiplication is : "+multi);
	}
}
