
public class Assignment3 {
	public static void main(String[] args){
		
		int a[]= {5,4,2,7,5,4,5,2};
		
		for(int i=0; i<a.length; i++)
		{
			
		}
	}
}
