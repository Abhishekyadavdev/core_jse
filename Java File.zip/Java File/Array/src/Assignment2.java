
public class Assignment2 {
	public static void main(String[] args) {
		
		int []a= {8,4,1,5,0,6};
		int min=a[0],
			term=0;
		
		System.out.print("Elements are : ");
			for(int x:a)
			{
				System.out.print(x+" ");
			}
			
			for(int i=1; i<a.length; i++) {
				if (a[i]<min)
				{
					min=a[i];
					term=i;
				}
			}
			
			System.out.println("\nMinimum Value are : "+min+
								"\nElementh term is : "+term);
		
	}
}
