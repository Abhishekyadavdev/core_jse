package p1.p2;

public class B {
	public int y=90;
}
