package p1;

class B {
	public int y=20;
	public void m2() {
		System.out.println("Hello B");
	}
}