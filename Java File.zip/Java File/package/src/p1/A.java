package p1;

public class A {
	int x=10;
	public void m1() {
		System.out.println("Hello A");
		//p1.B b=new p1.B();//allowed
		B b=new B();
		System.out.println(b.y);
		b.m2();
	}
}