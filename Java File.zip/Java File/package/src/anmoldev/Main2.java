//package anmoldev;
////import p1.A;
////import p1.B;
//import p1.*;
//import p2.*;
//import p1.A;
//import p2.D;
////import p2.A;//error
//public class Main2 {
//	public static void main(String[] args) {
//		A a=new A();
//		System.out.println(a.x);
//		a.m1();
//		p2.A aa=new p2.A();
//		System.out.println(aa.h);
//		aa.m();
//		B b=new B();
//		System.out.println(b.y);
//		b.m2();
//		p2.D d=new p2.D();
//		System.out.println(d.z);
//		d.m3();
//	}
//
//}