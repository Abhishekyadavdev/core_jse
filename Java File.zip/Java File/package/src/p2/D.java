package p2;

public class D {
	public int z=30;
	public void m3() {
		System.out.println("Hello D");
	}
}