
public class OperatorEx1 {

	public static void main(String[] args) {
		int a=7/2;
		System.out.println(a);
		double b=7/2;
		System.out.println(b);
		double c=7.0/2;
		System.out.println(c);
		double d=7/2.0;
		System.out.println(d);
		double e=7.0/2.0;
		System.out.println(e);
		//int f=7.0/2;//error
		int f=(int)7.0/2;
		//int f=(int)7.0/2.0;//error
		System.out.println(f);
		f=(int)(7.0/2.0);
		System.out.println(f);

	}

}
