
public class OperatorEx3 {

	public static void main(String[] args) {
		int a=8*2/4+6%3;
		System.out.println(a);
		
		a=12*4%5/3*7%8/2;
		System.out.println(a);

	}

}
