
public class TypeCastingEx2 {

	public static void main(String[] args) {
		char a='h';
		int b=a;
		System.out.println(a);
		System.out.println(b);
		
		int x=104;
		System.out.println((char)x); // allowed
		//char y=x;//error
		//char y=104;// allowed
		char y=(char)x;
		System.out.println(x);
		System.out.println(y);

	}

}
