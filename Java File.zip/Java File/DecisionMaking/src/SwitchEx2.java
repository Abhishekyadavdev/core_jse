
public class SwitchEx2 {

	public static void main(String[] args) {
		switch("mohan") {
		case "ram":
			System.out.println("Hi");
			break;
		case "mohan":
			System.out.println("Hello");
			break;
		default:
			System.out.println("Invalid Data.!");
	}
	}

}
