
public class SwitchEx3 {

	public static void main(String[] args) {
		switch("mohan") {
//		case 2:
//			System.out.println("Hi");
//			break;
		case "mohan":
			System.out.println("Hello");
			break;
		default:
			System.out.println("Invalid No.!");
	}
	
	switch("anmol") {
	case "2":
		System.out.println("Hi");
		break;
	case "mohan":
		System.out.println("Hello");
		break;
	default:
		System.out.println("Invalid No.!");
	}
	}

}
