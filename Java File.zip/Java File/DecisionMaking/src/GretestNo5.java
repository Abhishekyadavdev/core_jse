
public class GretestNo5 {

	public static void main(String[] args) {
		java.util.Scanner sc = new java.util.Scanner(System.in);

		System.out.println("Please enter first number: ");
		int a = sc.nextInt();
		System.out.println("Please enter second number: ");
		int b = sc.nextInt();
		System.out.println("Please enter third number: ");
		int c = sc.nextInt();
		System.out.println("Please enter fourth number: ");
		int d = sc.nextInt();
		System.out.println("Please enter fifth number: ");
		int e = sc.nextInt();
		
		if(a>b && a>c && a>d && a>e ) {
			System.out.println(a+" is Greater!");
		}else if(b>c && b>d && b>e) {
			System.out.println(b+" is Greater!");
		}else if(c>d && c>e) {
			System.out.println(c+" is Greater!");
		}else if(d>e) {
			System.out.println(d+" is Greater!");
		}else {
			System.out.println(e+" is Greater!");
		}

	}

}
