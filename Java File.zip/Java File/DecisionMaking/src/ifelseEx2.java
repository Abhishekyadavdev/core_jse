
public class ifelseEx2 {

	public static void main(String[] args) {
		if(2<3) 
			System.out.println("Hello");
			else 
			System.out.println("Hi");
			
		if(2<3) {
				System.out.println("Hello");
				System.out.println("Ok");
			}else {
				System.out.println("Hi");
			}
			System.out.println("Program Ended");
	}

}
