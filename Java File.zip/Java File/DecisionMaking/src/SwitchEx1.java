
public class SwitchEx1 {

	public static void main(String[] args) {
		switch(97) {
		case 'a':
			System.out.println("Hi");
			break;
		case 2:
			System.out.println("Hello");
			break;
		default:
			System.out.println("Invalid Data!");
	}
	}

}
