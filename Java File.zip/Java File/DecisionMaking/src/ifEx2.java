
public class ifEx2 {

	public static void main(String[] args) {
		java.util.Scanner sc=new java.util. Scanner( System.in );
		
		System.out.println("Enter a no: ");
		int a=sc.nextInt();
		if(a%5==0) {
			System.out.println(a+" is divisible by 5");
		}
		System.out.println("Prg Ended");
	}

}
