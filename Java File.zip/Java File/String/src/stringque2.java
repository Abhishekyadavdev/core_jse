
public class stringque2 {
	public static void main(String[] arg) {
		String name="Hello World";
		
			for(int x=name.length(); x>=1; x--)
			{
				System.out.println(name.substring(0,x));
			}
		
	}
}
