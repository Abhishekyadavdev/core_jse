
public class stringque3 {
	public static void main(String[] args) {
		String name="HelloWorld";
				
			int x=name.length();
			
			for(int i=0; i<=x; i++)
			{
				for(int j=x; j>=x-i+1;j--)
				{
					System.out.print(" ");
				}
				System.out.println(name.substring(i,x));
			}
	}
}
