import java.util.*;
public class stringque4 {
	public static void main(String[] args) {
		String name="Hello";
		
		int x=name.length();
		int p=x;

		for(int i=0;i<=x; i++) {
			System.out.println(name.substring(0,p));
			p--;
			
			for(int y=0; y<=i; y++)
			{
				System.out.print("*");
			}
		}
	}
}
// Not done 