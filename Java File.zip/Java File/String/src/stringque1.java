
public class stringque1 {
	public static void main(String[] args) {
		String name="Hello World";
		
		
		for(int x=1;x<=name.length();x++)
		{
			System.out.println(name.substring(0,x));
		}	
	}
}
