
public class Que1
{
	public static void main (String[] args) 
	{
	    java.util.Scanner in=new java.util.Scanner(System.in);
		// your code goes here
		int n;
		n=in.nextInt();
		for(int i=0; i<n; i++)
		{
		    int x=in.nextInt();
		    int y=in.nextInt();
		    
		    if(x<y) System.out.println("FIRST");
		    else if(x==y) System.out.println("ANY");
		    else System.out.println("SECOND");
		}
	}
}
