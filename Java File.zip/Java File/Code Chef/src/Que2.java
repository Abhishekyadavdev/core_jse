// Vol Control
public class Que2
{
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
		java.util.Scanner in=new java.util.Scanner(System.in);
		
		int t=in.nextInt();
		for(int i=0; i<t; i++)
		{
		    int count=0;
		    int x=in.nextInt();
		    int y=in.nextInt();
                
                if(x<y){
                }
                else{
                    int temp=x;
                    x=y;
                    y=temp;
                }
                
                for(int j=x; j<y; j++)
                {
                    count++;
                }
                
            System.out.println(count);
		}
	}
}
