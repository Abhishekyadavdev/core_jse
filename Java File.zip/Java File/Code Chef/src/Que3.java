// We have populated the solutions for the 10 easiest problems for your support.
// Click on the SUBMIT button to make a submission to this problem.

import java.util.*;
import java.io.*;

public class Que3{
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
//        float z=in.nextFloat();
       
        int x=in.nextInt();
        float y=in.nextFloat();
        float ch=0.50f;
        
        if(x%5==0)
        {
            if(x>y)
            	System.out.format("%.2f", y);
            else{
                float wd=(y-(float)x)-ch;
                System.out.format("%.2f", wd);
            }
        }
        else{
        	System.out.format("%.2f", y);
        }
        
    }
}

