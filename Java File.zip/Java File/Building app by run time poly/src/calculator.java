
public class calculator {
	void calculation(int x,int y) {
		System.out.println("This is calculator.");
	}
}
