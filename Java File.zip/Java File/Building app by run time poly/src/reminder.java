
public class reminder extends calculator{
	void calculation(int x,int y) {
		System.out.println(" result of Reminder : "+(x%y));
	}
}
