
public class multi extends calculator{
	void calculation(int x,int y) {
		System.out.println("Result of Multi : "+(x*y));
	}
}
