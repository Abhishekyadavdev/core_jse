
public class add extends calculator{
	void calculation(int x,int y) {
		System.out.println("Result of add : "+(x+y));
		
	}
	
}
