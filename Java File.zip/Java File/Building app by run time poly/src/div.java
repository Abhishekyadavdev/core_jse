
public class div extends calculator{
	void calculation(int x,int y) {
		System.out.println("result of div : "+(x/y));
	}
}
