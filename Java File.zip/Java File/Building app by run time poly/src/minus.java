
public class minus extends calculator {
	void calculation(int x,int y) {
		System.out.println("result of minus : "+(x-y));
	}
}
