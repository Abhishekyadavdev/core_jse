import java.io.IOException;
import java.util.*;

public class mainclass {

	public static void main(String[] args) throws IOException {
		Scanner in=new Scanner(System.in);
		
		System.out.println("Enter the two value : ");
		int x=in.nextInt();
		int y=in.nextInt();
		
		if(y>x)
		{
			int temp=x;
			x=y;
			y=temp;
			
			System.out.println("Replacing value ");
		System.out.println(x+" "+y);
		}	
		
		
//		char d=(char)System.in.read();
//		String dd=in.next();
		
		
//		System.out.println("Type Operator(+ , - , * , / , %) for Operation ");
		
		calculator c=new calculator();
		c.calculation(x,y);
		
		c=new add();
		c.calculation(x, y);
		
		c=new minus();
		c.calculation(x, y);
		
		c=new multi();
		c.calculation(x, y);
		
		c=new div();
		c.calculation(x, y);
		
		c=new reminder();
		c.calculation(x, y);
	}

}
