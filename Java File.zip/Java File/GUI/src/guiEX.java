import javax.swing.*;

class Gui{
	JFrame f;
	JButton b;
	JLabel l;
	JTextField tf;
		Gui(){
			f=new JFrame();
			f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			f.setTitle("First frame");
			f.setLayout(null);
			f.setSize(400,300);
			l=new JLabel("Anmol Dev...");
			l.setBounds(40,50,80,20);
			f.add(l);
			tf=new JTextField();
			tf.setBounds(40,150,150,20);
			f.add(tf);
			b=new JButton("okay");
			b.setBounds(40,190,40,40);
			f.add(b);
			f.setVisible(true);
		}
	
}
public class guiEX {

	public static void main(String[] args) {
		new Gui();

	}

}
