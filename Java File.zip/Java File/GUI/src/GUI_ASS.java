
import javax.swing.*;
//import java.awt.*;

public class GUI_ASS {
	public static void main(String[] args) {
		
	//window frame
		JFrame f=new JFrame();
		f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f.setTitle("MIni Calculator");
		f.setLayout(null);
		f.setSize(350, 400);
		
	// Label 
		//label 1.......
		JLabel l=new JLabel("Enter a No : ");
		l.setBounds(70,40,80,30);
		f.add(l);
		
		//label 2.......
		JLabel ll=new JLabel("Enter a No : ");
		ll.setBounds(70, 80, 80, 30);
		f.add(ll);
		
		//label 3.......
		JLabel lll=new JLabel("Answer : ");
		lll.setBounds(40, 210, 100, 20);
		f.add(lll);
		
		//label 4........
		JLabel llll= new JLabel("......................................................");
		llll.setBounds(110, 210, 300, 20);
		f.add(llll);
		
	// text field
		
		//textfield 1......
		JTextField tf=new JTextField();
		tf.setBounds(155, 48, 100, 20);
		f.add(tf);
				
		//textfield 2....
		JTextField tff=new JTextField();
		tff.setBounds(155, 85, 100, 20);
		f.add(tff);
	
	//buttons
		
		//button 1....
		JButton b=new JButton("+");
		b.setBounds(25, 140, 45,45);
		f.add(b);
		
		//button 2..
		JButton bb=new JButton("-");
		bb.setBounds(80, 140, 45, 45);
		f.add(bb);
		
		//button 3..
		JButton bbb=new JButton("*");
		bbb.setBounds(135, 140, 45, 45);
		f.add(bbb);

		//button 4..
		JButton bbbb=new JButton("/");
		bbbb.setBounds(190, 140, 45, 45);
		f.add(bbbb);
		
		JButton bbbbb=new JButton("%");
		bbbbb.setBounds(245, 140, 45, 45);
		f.add(bbbbb);
		
		
		
		f.setVisible(true);
	}
}
