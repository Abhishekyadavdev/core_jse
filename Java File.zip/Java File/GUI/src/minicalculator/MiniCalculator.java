package minicalculator;

import javax.swing.*;
import java.awt.*;
class Gui extends JFrame{
    JPanel p;
    JLabel l1,l2,l3,l4;
    JButton b1,b2,b3,b4,b5;
    JTextField t1,t2;
    Gui(){
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Mini Calci");
        setSize(410, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.yellow);
        
        Font f1=new Font(Font.SANS_SERIF, Font.BOLD, 14);
        Font f2=new Font(Font.MONOSPACED, Font.BOLD, 18);
        
        p=new JPanel();
        p.setLayout(null);
        //p.setBackground(Color.blue);
        p.setBackground(new Color(18, 79, 179));
        p.setBounds(20,20,355,170);
        add(p);
        
        l1=new JLabel("Enter 1st No:");
        l1.setBounds(20,20,100,30);
        l1.setForeground(Color.white);
        l1.setFont(f1);
        p.add(l1);
        t1=new JTextField();
        t1.setBounds(140,20,180,30);
        t1.setFont(f1);
        t1.setForeground(Color.red);
        t1.setHorizontalAlignment(0);
        p.add(t1);
        l2=new JLabel("Enter 2nd No:");
        l2.setBounds(20,70,100,30);
        l2.setForeground(Color.white);
        l2.setFont(f1);
        p.add(l2);
        t2=new JTextField();
        t2.setBounds(140,70,180,30);
        t2.setFont(f1);
        t2.setForeground(Color.red);
        t2.setHorizontalAlignment(0);
        p.add(t2);
        
        b1=new JButton("+");
        b1.setBounds(20,120,60,40);
        b1.setFont(f2);
        b1.setBackground(Color.darkGray);
        b1.setForeground(Color.white);
        p.add(b1);
        b2=new JButton("-");
        b2.setBounds(85,120,60,40);
        b2.setFont(f2);
        b2.setBackground(Color.darkGray);
        b2.setForeground(Color.white);
        p.add(b2);
        b3=new JButton("*");
        b3.setBounds(150,120,60,40);
        b3.setFont(f2);
        b3.setBackground(Color.darkGray);
        b3.setForeground(Color.white);
        p.add(b3);
        b4=new JButton("/");
        b4.setBounds(215,120,60,40);
        b4.setFont(f2);
        b4.setBackground(Color.darkGray);
        b4.setForeground(Color.white);
        p.add(b4);
        b5=new JButton("%");
        b5.setBounds(280,120,60,40);
        b5.setFont(f2);
        b5.setBackground(Color.darkGray);
        b5.setForeground(Color.white);
        p.add(b5);
        
        l3=new JLabel("Answer:");
        l3.setBounds(40,210,100,30);
        l3.setFont(f2);
        add(l3);
        l4=new JLabel("--------");
        l4.setBounds(200,210,100,30);
        l4.setFont(f2);
        l4.setForeground(Color.blue);
        add(l4);
    }
}
public class MiniCalculator {
    public static void main(String[] args) {
        new Gui().setVisible(true);
    }
}