
public class area_circle {

	public static void main(String[] args) {
		double r=10.0;
		double area= (r*r)*3.14159;
		System.out.println(" area of circle : "+area);
	}

}
