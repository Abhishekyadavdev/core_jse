
public
class
GappingRule 
{

	public
	static
	void
	main(
			String[
			       ]
			    		   
			    		   args
			    		   )
	{
		        System.
		        out
		        .
		        println(
		        		"Hello Anmol"
		        		)
		        ;
		    }
	}
