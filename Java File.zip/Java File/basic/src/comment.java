
public class comment {

	public static void main(String[] args) {
		// java is amazing
		
		/*
		 * java 
		is
		amazing
		*/
		
		// this all about comment 
		// inline or multiline comments
	}

}
