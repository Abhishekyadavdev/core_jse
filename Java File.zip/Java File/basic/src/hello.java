
public class hello {

	public static void main(String[] args) {
		System.out.println("Hello Anmol");
		System.out.print("Hello Anmol");
		System.out.format("Hello Anmol");
		System.out.printf("Hello Anmol");
		
		    }
	}
