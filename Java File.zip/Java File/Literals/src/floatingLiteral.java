
public class floatingLiteral {
	public static void main(String[] args) {
		float a=256.98412f;//Simple Floating Point Literal
        double b=2.5698412e+2;//Exponential Floating Point Literal
        System.out.println(a);
        System.out.println(b);

        double x=2_56.98_412;
        //double x=_2_56.98_412_;//error
        //double x=2_56_._98_412;//error
        System.out.println(x);
	}
}
