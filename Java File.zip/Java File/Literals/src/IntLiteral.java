
public class IntLiteral {

	public static void main(String[] args) {
			int a=10;		//decimal
			System.out.println(a);
			a=012;			//octal
			System.out.println(a);	
			a=0b1100110;	//binary
			//a=oB1100100;	//allowed
			System.out.println(a);
			a=0x92a;		//hexa-decimal
			//a=0X92A;	//allowed
			System.out.println(a);
			
			//countable 
			a=5_43_34_500;
			// a=_5_43_34_500_;	//error
			System.out.println(a);
	
			//interview question
			// int x=08;	// octal-- Error
			// int x=09;	// octal== Error
			int x=07;
			System.out.println(x);
			
	}

}
