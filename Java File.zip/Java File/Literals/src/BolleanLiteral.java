
public class BolleanLiteral {

	public static void main(String[] args) {
		boolean a=true;//Boolean Literal
        boolean b=false;//Boolean Literal
        //boolean a=True;//error
        //boolean a="false";//error
        //boolean a='false';//error
        System.out.println(a);
        System.out.println(b);
	}

}
