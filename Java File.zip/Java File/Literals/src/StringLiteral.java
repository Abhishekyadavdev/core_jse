
public class StringLiteral {
public static void main(String[] args) {
	String a="Anmol Dev..";//String Literal
    String b="104";//String Literal
    System.out.println(a);
    System.out.println(b);
}
}
