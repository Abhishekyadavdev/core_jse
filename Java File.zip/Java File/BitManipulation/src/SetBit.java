
public class SetBit {
	public static void main(String[] args) {
		// Set Bit means : We now using this to replace Bit that term.
		int n=10; 
		int pos=3,
			mask= 1<<pos;
		
        // 5= (0101)
        // shifting 1 by 3 postion 00001 --->  001000
		
        int bitresult= n | mask;
        // opertion USing Or 
        // n= 00101 (5)
    //  mask= 01000 (8)
    //result= 01101 (13)
        
        System.out.println("Befor Set Bit value is : "+n+
        					"\nAfter Set Bit value is : "+bitresult);
        // System.out.println(mask);
		
	}
}

//because
//0 + 0 = 0
//1 + 0 = 1
//0 + 1 = 1
//1 + 1 = 1