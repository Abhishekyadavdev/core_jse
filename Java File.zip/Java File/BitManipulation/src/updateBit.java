public class updateBit {
   public static void main(String[] args) {
       int n=5; int pos=2; int mask=1<<pos; 
        // 5= (0101)
        // shifting 1 by 2 postion 00001 --->  00100
        int value=0;
        // if value 1 that means set the vlue that position
        // else value 0 that means delete the vlue that 
       if(value==1)
       {
        // set bit 
            int result= mask | n;
            System.out.println(result);
       }
       else{
        // clear bit
        mask=(~mask); 
        int result= mask & n;
        System.out.println(result);
       }
    }
}

