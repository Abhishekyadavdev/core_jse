
public class nagation {
	public static void main(String[] args) {
		int x=5;
		System.out.println(x);
		x= ~x;
		System.out.println(x);
		System.out.println((-x));
		
		
		
	}
}

//in Compiler method is : 
//	x=5 ---> binary is : (0.....0101)
//~x --> after nagation binary is : (1.....1010)		<-- 1st compliment (1 changes to 0 and 0 to 1).
//
//	And then second compliment -->  (0.....0101)
//											 +1
//									------------
//									(0.....0110)	==> (-6)
//									------------


// in shortcut method for finding
//	--> -(x+1)	or -1(x+1)
//		
//	-(5+1)	or -1(5+1)
//	-(6)	or -1(6)
//	-6		or 	-6