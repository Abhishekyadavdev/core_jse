
public class getBit {

	public static void main(String[] args) {
		// GetBit means : Knowing the which bit 0,1 there -- using get-Bit
		
		int x=10; //10 in binary is [.....0001010]
			
			int term=2, 
				mask=1<<term; // 1 shifting by term(2) --> 1 =(...0001) ,after shifting (...000100) 
			
			if((mask & x)==0) 
							//  			mask => 	...000100
							//  & Operation with x => 	...001010
							// 			result will Be : ..000000  
			{
				System.out.println(x+" is hold 0 on "+term+" position ");
			}
			else{
				System.out.println(x+" is hold 1 on "+term+" position ");
			}
				
			
				
	}
}
//beacuse in & operation
//0 + 0 = 0
//0 + 1 = 0
//1 + 0 = 0
//1 + 1 = 1