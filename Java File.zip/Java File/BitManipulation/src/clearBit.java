public class clearBit {
   public static void main(String[] args) {
        int n=5; int pos=2; int mask= 1<<pos;
        // 5= (0101)
        // shifting 1 by 2 postion 00001 --->  00100
        System.out.println(mask);
        mask= (~mask);
        // after tild (nagation,compliment) = 00100 --> 11011
        int bitresult= n & mask;
        // opertion USing Or 
        // n= 00101 (5)
    //  mask= 11011 (-4)
    //result= 00001 (1)
        System.out.println("Befor Set Bit value is : "+n+"\nAfter Set Bit value is : "+bitresult);
//         System.out.println(mask);
        
//       System.out.println(~mask);
    }
}

// first change mask to ~ mask
// then complete operation with mask & n ;