
public class left_right_shift {
	public static void main(String[] args) {
		int a=10,	//10 in binary : [.....0001010]
			b=20;	//20 in binary : [.....0010100]
		
		System.out.println(a);	//10
		System.out.println(b);	//20
		
		//left shift {Here Zero, will be come from right to left means ..100 --> ..1000}
		
		System.out.println(a<<1);	//{ 10<<1 } --> [.....0001010 ---> .....0010100] = 20
		System.out.println(b<<1);	//{ 20<<1 } --> [.....0010100 ---> .....0101000] = 40
		
		//Right Shift {Here Zero, will be come from right to left means ..100 --> ..010}
		System.out.println(a>>1);	//{ 10>>1 } --> [.....0001010 ---> .....0000101] = 5
		System.out.println(b>>1);	//[ 20>>1 } --> [.....0010100 ---> .....0001010] = 10
		
		//Left 7 Right Shift by 2
		System.out.println(a<<2);  //{ 10<<2 } --> [.....0001010 ---> .....0101000] = 40
		System.out.println(a>>2);  //{ 10>>2 } --> [.....0001010 ---> .....0000010] = 2
		
		
	}
}
