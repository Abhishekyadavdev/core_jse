package p1;

public class A {
	protected int x=10;
}
