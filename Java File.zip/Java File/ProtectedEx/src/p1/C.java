package p1;

public class C extends A {
	public void m() {
		System.out.println(x);
	}
}
