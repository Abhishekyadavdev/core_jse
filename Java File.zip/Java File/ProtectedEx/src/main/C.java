package main;

import p1.A;

public class C extends A {
	public void m() {
		System.out.println(x);
		A a=new A();
		//System.out.println(a.x);//error
		C c=new C();
		System.out.println(c.x);//allowed
	}
}
