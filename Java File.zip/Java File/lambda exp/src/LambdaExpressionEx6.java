@FunctionalInterface
interface Abc{
	void xyz();
}
public class LambdaExpressionEx6 {

	public static void main(String[] args) {
		Abc a=()-> System.out.println("Hello"); 
		a.xyz();
		a.xyz();
	}

}